


<?php $__env->startSection('content'); ?>
<div class='content'>
    <div class="container">
        <h3>Media Downloads</h3>

        <table class='display' id='tableID'>
            <thead class='thead-dark'>
                <tr align="center">
                    <th>ID</th>
                    <th>RoomSid</th>
                    <th>Links</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr align="center">
                        <td scope="row"><?php echo e($record->RecordingSid); ?></td>
                        <td>
                            <?php echo e($record->RoomSid); ?>

                        </td>
                        <td>
                            <a class="btn btn-primary btn-block" href="<?php echo e($mediaLocation[$record->RecordingSid]); ?>" role="button">Download</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </table>
    </div>

    

</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    $('#tableID').DataTable();
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\record\index.blade.php ENDPATH**/ ?>