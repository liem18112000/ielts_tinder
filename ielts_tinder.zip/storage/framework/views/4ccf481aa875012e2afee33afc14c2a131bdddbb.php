

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNotifications.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class='content'>
    <div class="container">

        <br/><br/>
        <h3>User Management</h3>

        <table class="table table-hover table-inverse table-responsive" style='height: 70vh; overflow-y: scroll;'>
            <thead class="thead-dark">
                <tr align='center'>
                    <th class='desktop-view'>ID</th>
                    <th>Name</th>
                    <th class='desktop-view'>Email</th>
                    <th class='desktop-view'>OAuth</th>
                    <th>Status</th>
                    <th>Last seen</th>
                </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $users['online']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr align='center'>
                        <td scope="row" class='desktop-view'><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td class='desktop-view'>
                            <?php if(!$user->email): ?>
                                Not Available
                            <?php else: ?>
                                <?php echo e($user->email); ?>

                            <?php endif; ?>
                        </td>
                        <td class='desktop-view'>
                            <?php if(!$user->provider): ?>
                                System
                            <?php else: ?>
                                <?php echo e($user->provider); ?>

                            <?php endif; ?>
                        </td>
                        <td><b style='color:green'>Online</b></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->last_seen)->diffForHumans()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $users['offline']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr align="center">
                        <td scope="row" class='desktop-view'><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td class='desktop-view'>
                            <?php if(!$user->email): ?>
                                Not Available
                            <?php else: ?>
                                <?php echo e($user->email); ?>

                            <?php endif; ?>
                        </td>
                        <td class='desktop-view'>
                            <?php if(!$user->provider): ?>
                                System
                            <?php else: ?>
                                <?php echo e($user->provider); ?>

                            <?php endif; ?>
                        </td>
                        <td><b style='color:red'>Offline</b></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->last_seen)->diffForHumans()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
        </table>
    </div>

    <div class="icon">
        <div class="row align-items-center">
            <div class="col">
                <a href="<?php echo e(route('feeds.index')); ?>"> <img id="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('search')); ?>"> <img id="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <div class="backgroundRound">
                    <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                </div>
            </div>
            <div class="col">
                <a href="<?php echo e(route('notify.index')); ?>"> <img id="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img id="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
            </div>
        </div>
    </div>
</div>

<div class="backgroundBar"></div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/user/index.blade.php ENDPATH**/ ?>