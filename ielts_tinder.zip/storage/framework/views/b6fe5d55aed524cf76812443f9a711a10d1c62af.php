



<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/stylesProfile.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
    <script src='https://cdn.fusioncharts.com/fusioncharts/latest/fusioncharts.js'></script>
    <script src='https://cdn.fusioncharts.com/fusioncharts/latest/themes/fusioncharts.theme.fusion.js'></script>
    <script>
        const dataSource = {
            chart: {
            showvalues: "0",
            caption: "Individual Evaluation",
            subcaption: "(2020)",
            plottooltext: "Score of $seriesName in $label was <b>$dataValue</b>",
            showhovereffect: "1",
            yaxisname: "Band Score",
            showsum: "1",
            theme: "fusion",
            animationEnabled: true,
            },
            categories: [
                {
                    category: [
                        {
                            label: "Jan"
                        },
                        {
                            label: "Feb"
                        },
                        {
                            label: "Mar"
                        },
                        {
                            label: "Apr"
                        },
                        {
                            label: "May"
                        },
                        {
                            label: "Jun"
                        },
                        {
                            label: "Jul"
                        },
                        {
                            label: "Aug"
                        },
                        {
                            label: "Sep"
                        },
                        {
                            label: "Oct"
                        },
                        {
                            label: "Nov"
                        },
                        {
                            label: "Dec"
                        }
                    ]
                }
            ],
            dataset: [
                {
                    seriesname: "Fluency and coherence",
                    data: [
                        {
                            value: 4/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 5/4
                        },
                        {
                            value: 5.5/4
                        },
                        {
                            value: 6/4
                        },
                        {
                            value: 6.5/4
                        },
                        {
                            value: 7.5/4
                        },
                        {
                            value: 8/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 9/4
                        }
                    ]
                },
                {
                    seriesname: "Lexical resource",
                    data: [
                        {
                            value: 4/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 5/4
                        },
                        {
                            value: 5.5/4
                        },
                        {
                            value: 6/4
                        },
                        {
                            value: 6.5/4
                        },
                        {
                            value: 7.5/4
                        },
                        {
                            value: 8/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 9/4
                        }
                    ]
                },
                {
                    seriesname: "Grammatical range and accuracy",
                    data: [
                        {
                            value: 4/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 5/4
                        },
                        {
                            value: 5.5/4
                        },
                        {
                            value: 6/4
                        },
                        {
                            value: 6.5/4
                        },
                        {
                            value: 7.5/4
                        },
                        {
                            value: 8/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 9/4
                        }
                    ]
                },
                {
                    seriesname: "Pronunciation",
                    data: [
                        {
                            value: 4/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 4.5/4
                        },
                        {
                            value: 5/4
                        },
                        {
                            value: 5.5/4
                        },
                        {
                            value: 6/4
                        },
                        {
                            value: 6.5/4
                        },
                        {
                            value: 7.5/4
                        },
                        {
                            value: 8/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 8.5/4
                        },
                        {
                            value: 9/4
                        }
                    ]
                },
                {
                    seriesname: "Speaking Score",
                    plottooltext: "Total Speaking Score in $label was <b>$dataValue</b>",
                    renderas: "Line",
                    data: [
                        {
                            value: "4.0"
                        },
                        {
                            value: "4.5"
                        },
                        {
                            value: "4.5"
                        },
                        {
                            value: "5.0"
                        },
                        {
                            value: "5.5"
                        },
                        {
                            value: "6.0"
                        },
                        {
                            value: "6.5"
                        },
                        {
                            value: "7.5"
                        },
                        {
                            value: "8.0"
                        },
                        {
                            value: "8.5"
                        },
                        {
                            value: "8.5"
                        },
                        {
                            value: "9"
                        }
                    ]
                }
            ]
        };

        FusionCharts.ready(function() {
        var myChart = new FusionCharts({
            type: "stackedcolumn2dline",
            renderAt: "chart-container",
            width: "100%",
            height: "100%",
            dataFormat: "json",
            dataSource
            }).render();
        });
    </script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

	<div class="content">
        <div class="container">

            <div class="row">
                <div class="col-6 info">
                    <h2 style='margin-top:50px'><?php echo e($profile->user->name); ?></h2>
                    <div class="row">
                        <!-- <img src="<?php echo e(asset('image/location.png')); ?>" class="age" alt=""> -->
                        <span class="detail">
                            <?php if(!$profile->home): ?>
                                Not Available
                            <?php else: ?>
                                <?php echo e($profile->home); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="row">

                        <span class="detail">
                            <?php if(!$profile->dob): ?>
                                Not Available
                            <?php else: ?>
                                <?php echo e($profile->dob); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="row2">
                        <div class="col-4">
                            <a href='<?php echo e(route('profile.edit', $profile)); ?>' class="btn btnEdit2">Edit Profile</a>
                        </div>
                        <div class="col-8">
                            <a class="btn btnEdit2" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="row d-flex justify-content-center"> <img style='border-radius:50%' src="<?php echo e($profile->profile_image); ?>" class="avatar-profile" alt=""></div>
                </div>
            </div>
            <div class="row descrip">
                <span>
                    <?php echo $profile->intro; ?>

                </span>
            </div>
            <div class="row3">
                <div class="col-1"></div>
                <div class="col-5">
                    <span class="amount-follower">31</span> Follower
                </div>

                <div class="col-5">
                    <span class="amount-following">125</span> Following
                </div>
            </div>

            <hr>
            <div class="row descrip2">
                <input type="button" class="button" value="Update New Audio">
            </div>
            <div class="row learn">
            <div class="grid_type">
                <div class="row score">
                    <img src="<?php echo e(asset('image/score.png')); ?>" id="score" alt="">
                    <span class="score-detail">IELTS Band Scores: </span>
                    <span class="current-score"><?php echo e($profile->band_score); ?></span>
                </div>

                <div class="row score1">
                    <img src="<?php echo e(asset('image/playaudio.png')); ?>" id="score1" alt="">
                    <span class="score-detail"> Audio Collection: </span>
                </div>

                <div class="displayvideo">
                    <iframe width="180" height="220" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                    </iframe>
                    <iframe width="180" height="220" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                    </iframe>
                </div>

                <div class="row score2">
                    <img src="<?php echo e(asset('image/sharing.png')); ?>" id="score1" alt="">
                    <span class="score-detail"> Sharing Collection: </span>
                </div>

        </div>


                <div class="row evalution">
                    <div id="chart-container"></div>
                </div>
            </div>

        </div>

        <div class="icon">
            <div class="row align-items-center">
                <div class="col">
                    <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <div class="backgroundRound">
                        <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                    </div>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
                </div>
            </div>
        </div>

    </div>

    <div class="backgroundBar"></div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/profile/show.blade.php ENDPATH**/ ?>