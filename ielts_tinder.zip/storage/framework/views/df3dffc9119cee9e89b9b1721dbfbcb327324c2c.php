<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/stylesAboutPartner.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <form action="#" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <h3>About your partner</h3>
        <input type="radio" id="male" name="gender" value="male">
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="female">
        <label for="female ">Female</label>
        <input type="number" class="Input " placeholder="Age">
        <input type="text" class="Input " placeholder="Hometown">
        <input type="text" class="Input " placeholder="Practime">
        <input type="text" class="Input " placeholder="Estimate speaking band score">
        <div class="mt-3 mx-auto" style="width: 200px;">
            <a href="#" id="linkBtn3"><button type="button" class="btn btn-lg btnLink" onclick="SignIn()">Done </button></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\about-partner.blade.php ENDPATH**/ ?>