# Info

Welcome to the generated API reference.
<?php if($showPostmanCollectionButton): ?>
[Get Postman Collection](<?php echo e(url($outputPath.'/collection.json')); ?>)
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\vendor\mpociot\laravel-apidoc-generator\src/../resources/views//partials/info.blade.php ENDPATH**/ ?>