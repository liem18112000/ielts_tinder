<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH C:\xampp\htdocs\ielts_tinder\vendor\binarytorch\larecipe\src/../resources/views/partials/sidebar.blade.php ENDPATH**/ ?>