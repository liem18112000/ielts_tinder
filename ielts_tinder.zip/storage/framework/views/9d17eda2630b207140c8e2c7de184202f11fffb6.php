

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNotifications.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class='content'>
    <div class="container">

        <div class='row'>

            <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-4 mt-4'>

                <h3>Create new room</h3>

                <form action = '<?php echo e(route('room.create')); ?>' method='post'>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="room">Room Name</label>
                        <input type="text" name="room" id="room" class="form-control" value="<?php echo e($newRoomName); ?>"
                            placeholder="Enter room name" aria-describedby="helpId" required="required">
                        <small id="helpId" class="text-muted">You can change room name if you want</small>
                    </div>
                    <div class="form-group">
                        <label for="">Room Type</label>
                        <select class="form-control" name="type" id="type" aria-describedby="helpId2">
                            <option value='group-small'>Recommended : Small room with 4 users</option>
                            <option value='peer-to-peer'>Private room with 2 users only </option>
                            <option value='group'> Regular room with 50 users or more </option>
                        </select>
                        <small id="helpId2" class="text-muted">Choose room type</small>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Go!</button>
                </form>

            </div>


            <?php if($rooms): ?>

            <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>

                <h3>List of Rooms</h3>

                <table class="table table-striped table-inverse table-responsive" >
                    <thead class="thead-inverse" >
                        <tr style="text-align:center">
                            <th style="width: 50%;">Name</th>
                            <th style="width: 50%;">Type</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="text-align:center">
                                <td scope="row"><?php echo e($room->uniqueName); ?></td>
                                <td>
                                    <?php if($room->type == 'peer-to-peer'): ?>
                                        Private
                                    <?php elseif($room->type == 'group-small'): ?>
                                        Small
                                    <?php else: ?>
                                        Regular
                                    <?php endif; ?>
                                </td>
                                <td style='padding: 4px;'>
                                    <a class="btn btn-primary btn-block" style="margin: 0" href="<?php echo e(route('room.join', $room->uniqueName)); ?>" role="button">Join</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
            </div>

            <?php endif; ?>
        </div>


    </div>
    <div class="icon">
        <div class="row align-items-center">
            <div class="col">
                <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <div class="backgroundRound">
                    <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                </div>
            </div>
            <div class="col">
                <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
            </div>
        </div>
    </div>

</div>

<div class="backgroundBar"></div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\room\index.blade.php ENDPATH**/ ?>