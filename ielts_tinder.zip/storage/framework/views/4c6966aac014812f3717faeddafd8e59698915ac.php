



<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesSearch.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">

        <div class="container-fluid" style='padding-bottom: 15%'>

            <span class="row SearchTool">
                <div class="col-2 Icon">
                    <a href=""> <i class="fas fa-search"></i></a>
                </div>
                <div class="col-8 inputBar">
                    <input type="text" placeholder="Searching">
                </div>
            </span>

            <?php for($i = 0; $i < 10; $i++): ?>
            <div class="category row">
                <div class="col-1 sharp">
                    <span id="sharp">#</span>
                </div>
                <div class="col-11">
                    <span id="category">Pet</span>
                </div>
            </div>
            <div class="row listVideo">
                <div class="col-1"></div>
                <div class="col-re-3">
                    <div class="embed-responsive embed-responsive-1by1">
                        <iframe class="embed-responsive-item multimedia"
                            src="https://www.youtube.com/embed/lHJN6IO6jYI"></iframe>
                    </div>
                </div>
                <div class="col-re-3">
                    <div class="embed-responsive embed-responsive-1by1">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/lHJN6IO6jYI"></iframe>
                    </div>
                </div>
                <div class="col-re-3">
                    <div class="embed-responsive embed-responsive-1by1">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/lHJN6IO6jYI"></iframe>
                    </div>
                </div>
                <div class="col-re-3">
                    <div class="embed-responsive embed-responsive-1by1">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/lHJN6IO6jYI"></iframe>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>

        <div class="icon">
            <div class="row align-items-center">
                <div class="col">
                    <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <div class="backgroundRound">
                        <a href="<?php echo e(route('home')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                    </div>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <div class="backgroundBar"></div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\search.blade.php ENDPATH**/ ?>