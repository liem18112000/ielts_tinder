

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesRoomMatching.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <div class="content">
        <div class="container">
        <h3>MATCHING</h3>
        <?php $__currentLoopData = $onlineUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id != Auth::user()->id): ?>
                <div class="noti">
                <div class="row"> 
                    <div class="col-6">
                        <div class="row"> <img style='border-radius:10%' src="<?php echo e($user->profile->profile_image); ?>" class="avatar-profile" alt=""></div>
                    </div>
                    <div class="col-6" style="margin-left:-15px; margin-right:-15px;">
                        <h5 style='margin-top:10px; font-size:16px; font-weight:bold;'><?php echo e($user->name); ?></h5>
                        <div class="row" style="margin-bottom:5px">
                            <img src="<?php echo e(asset('image/score.png')); ?>" class="score" alt="">
                            <span class="detail">
                                <?php if(!$user->profile->band_score || $user->profile->band_score == 0.0): ?>
                                    Not Available
                                <?php else: ?>
                                    <?php echo e($user->profile->band_score); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="row" style="margin-bottom:5px">
                            <img src="<?php echo e(asset('image/player.png')); ?>" class="score" alt="">
                            <span class="detail">
                                ???
                            </span>
                        </div>
                        <div class="row">
                            <img src="<?php echo e(asset('image/Age.png')); ?>" class="score" alt="">
                            <span class="detail">
                                <?php if(!$user->profile->dob): ?>
                                    Not Available
                                <?php else: ?>
                                    <?php echo e($user->profile->dob); ?>

                                <?php endif; ?>
                            </span>
                        </div>  
                    </div>
                </div>
                <div class="row descrip">
                    <span>
                        <?php echo e($user->profile->intro); ?>

                    </span>
                </div>
                <div class="row" style="margin-bottom:10px">
                    <div class="col-6">
                        <a class="btnMore" href="" role="button">MORE</a>
                    </div>
                    <div class="col-6">
                        <a class="btnMatch" style="color:white;" href="" role="button">MATCH</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="icon">
            <div class="row align-items-center">
                <div class="col">
                    <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <div class="backgroundRound">
                        <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                    </div>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
                </div>
            </div>
        </div>
    </div>



    <div class="backgroundBar"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/room/matching.blade.php ENDPATH**/ ?>