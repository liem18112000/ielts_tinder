

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesAboutYourself.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="anh"><img src="<?php echo e(asset('image/profile.png')); ?>" alt=""></div>
<div class="content">
    <form>
        <input type="text" class="Input" placeholder="Full name">
        <input type="radio" id="male" name="gender" value="male">
        <label for="male" >Male</label>
        <input type="radio" id="female" name="gender" value="female">
        <label for="female ">Female</label>
        <input type="text" class="Input " placeholder="Birthday">
        <input type="text" class="Input " placeholder="Hometown">
        <input type="text" class="Input " placeholder="Your native languages">
        <input type="text" class="Input " placeholder="IELTS Target">
        <input type="text" class="Input " placeholder="Estimate speaking band score">
        <input type="text" class="Input Practime" placeholder="Practime">
        <div class="mt-3 mx-auto" style="width: 200px;">
            <a href="<?php echo e(route('about-partner')); ?>" id="linkBtn5"><button type="button" class="btn btn-lg btnLink" onclick="AboutPartner()">Next</button></a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/about-yourself.blade.php ENDPATH**/ ?>