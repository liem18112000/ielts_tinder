



<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNotifications.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('head'); ?>

<script src="http://media.twiliocdn.com/sdk/js/video/releases/1.20.1/twilio-video.min.js"></script>

<script>
    function trackAdded(div, track) {
        div.appendChild(track.attach());
        var video = div.getElementsByTagName("video")[0];
        if (video) {
            video.setAttribute("style", "max-width:85vw;");
        }
    }

    function trackRemoved(track) {
        track.detach().forEach( function(element) { element.remove() });
    }

    function participantConnected(participant) {
        console.log('Participant "%s" connected', participant.identity);

        const div = document.createElement('div');
        div.id = participant.sid;
        div.classList.add("card");
        div.setAttribute("style", "float: left; margin: 10px;");

        content =  "<div class='card-header' style='display:flex; justify-content: space-around; ;clear:both; padding:6px'>";

        if(participant.identity == '<?php echo e($identity); ?>'){
            localParticipant = participant;
            content += "<button class='btn btn-dark btn-block'> You </button>" +
                "&nbsp <button id='" + participant.identity + "sound' class='btn btn-primary'>Mute</button>" +
                "&nbsp <button id='" + participant.identity + "video' class='btn btn-success'>On</button>"
                "</div>";
        }else{
            content += participant.identity + "</div>";
        }

        div.innerHTML = content;

        participant.tracks.forEach(function(track) {
            trackAdded(div, track)
        });

        participant.on('trackAdded', function(track) {
            trackAdded(div, track)
        });

        participant.on('trackRemoved', trackRemoved);

        document.getElementById('media-div').appendChild(div);
    }

    function participantDisconnected(participant) {
        console.log('Participant "%s" disconnected', participant.identity);

        participant.tracks.forEach(trackRemoved);
        document.getElementById(participant.sid).remove();
    }

    var localParticipant = null;

    Twilio.Video.createLocalTracks({
       audio: true,
       video: { width: 800 }
    }).then(function(localTracks) {
        return Twilio.Video.connect('<?php echo e($accessToken); ?>', {
            name: '<?php echo e($room); ?>',
            tracks: localTracks,
            video: { width: 800 }
        });
    }).then(function(room) {
        console.log('Successfully joined a Room: ', room.name);

        room.participants.forEach(participantConnected);

        var previewContainer = document.getElementById(room.localParticipant.sid);
        if (!previewContainer || !previewContainer.querySelector('video')) {
            participantConnected(room.localParticipant);
        }

        room.on('participantConnected', function(participant) {
            console.log("Joining: '" +  participant.identity + "'");
            participantConnected(participant);
        });

        document.getElementById(localParticipant.identity + 'video').addEventListener("click", function(){
            if(document.getElementById(localParticipant.identity + 'video').innerText == 'On'){
                localParticipant.videoTracks.forEach(function(videoTrack) {
                    console.log('+++++ videoTrack ' + localParticipant.identity + ' Disable :  ' + videoTrack + ' +++++');
                    videoTrack.disable();
                });
                document.getElementById(localParticipant.identity + 'video').innerText = "Off";
            }else{
                localParticipant.videoTracks.forEach(function(videoTrack) {
                    console.log('+++++ videoTrack ' + localParticipant.identity + ' Enable ' + videoTrack + ' +++++');
                    videoTrack.enable();
                });
                document.getElementById(localParticipant.identity + 'video').innerText = "On";
            }
        });

        document.getElementById(localParticipant.identity + 'sound').addEventListener("click", function(){
            if(document.getElementById(localParticipant.identity+ 'sound').innerText == 'Mute'){
                localParticipant.audioTracks.forEach(function(audioTrack) {
                    console.log('+++++ audioTrack ' + localParticipant.identity + ' Disable :  ' + audioTrack + ' +++++');
                    audioTrack.disable();
                });
                document.getElementById(localParticipant.identity + 'sound').innerText = "Unmute";
            }else{
                localParticipant.audioTracks.forEach(function(audioTrack) {
                    console.log('+++++ audioTrack ' + localParticipant.identity + ' Enable ' + audioTrack + ' +++++');
                    audioTrack.enable();
                });
                document.getElementById(localParticipant.identity + 'sound').innerText = "Mute";
            }
        });


        room.on('participantDisconnected', function(participant) {
            console.log("Disconnected: '" + participant.identity + "'");
            participantDisconnected(participant);
        });
    });

</script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content">
    <div class='container text-center'>

        <br/>

        <h3><?php echo e($room); ?></h3>

        <div id="media-div">

        </div>
    </div>
</div>

<div class="icon">
    <div class="row align-items-center">
        <div class="col">
            <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
        </div>
        <div class="col">
            <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
        </div>
        <div class="col">
            <div class="backgroundRound">
                <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
            </div>
        </div>
        <div class="col">
            <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
        </div>
        <div class="col">
            <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
        </div>
    </div>
</div>

<div class="backgroundBar"></div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\room\room.blade.php ENDPATH**/ ?>