



<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNotifications.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
     <div class="content">
        <div class="container">

            <div class="row">
                <img src="<?php echo e(asset('image/mess.png')); ?>" class="mess" alt="">
            </div>
            <h3 style='margin-top: 10px'>Notifications</h3>

            <div class="noti">
                <div class="row">
                    <div class="col-4"><span id="notifi">Notifications</span></div>
                    <div class="col-4"></div>
                    <div class="col-4"><span><a href=""> View all</span></a></div>
                </div>
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="noti-1 row">
                    <div class="col-3">
                        <img src="<?php echo e($notification->sender->profile->profile_image); ?>" class="avatar" alt="">
                    </div>
                    <div class="col-9 notiMess">
                        <div class="row messNoti">
                            <span><a href=""><?php echo e($notification->sender->name); ?></a> </span>
                            <span><?php echo e($notification->content); ?></span>
                        </div>
                        <?php
                        $result = $notification->created_at->toDateTimeString();
                        ?>
                        <div class="row timeNoti"><span><?php echo e($result); ?></span></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

        <div class="icon">
            <div class="row align-items-center">
                <div class="col">
                    <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <div class="backgroundRound">
                        <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                    </div>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
                </div>
                <div class="col">
                    <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
                </div>
            </div>
        </div>
    </div>



    <div class="backgroundBar"></div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/notification/index.blade.php ENDPATH**/ ?>