;

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNewsfeed-moment.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class='container' style='min-height:90vh'>
            <div class="chamthan_menu">
                <div class="menu">
                    <span><a href="<?php echo e(route('feeds.index')); ?>" class="linkNewsfeed navlink following">Following</a></span> |
                    <span><a href="<?php echo e(route('feeds.moment')); ?>" class="linkNewsfeed navlink moments">Hot</a></span>
                </div>

                <div class="chamthan">
                    <img class="chamthanicon" src="<?php echo e(asset('image/icon_chamthan.png')); ?>" alt=""></a>
                </div>
            </div>

            <?php $__currentLoopData = $feeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row status-1">
                <div class="col-2">
                    <img style='border-radius: 50%' src="<?php echo e($feed->user->profile->profile_image); ?>" alt="avatar" class="avatar">
                </div>
                <div class="col-10">
                    <div class="row username">
                        <a href=""><?php echo e($feed->user->name); ?></a>
                    </div>
                    <div class="row status">
                        <p><?php echo e($feed->content); ?></p>
                    </div>
                </div>
            </div>
            <div class="row multimedia mt-4">

                <?php if($feed->media_type == "video"): ?>
                    <video width="100%" height="100%" controls>
                        <source src="<?php echo e($feed->media); ?>" type="video/<?php echo e($feed->media_ext); ?>">
                        Your browser does not support the video tag.
                    </video>
                <?php elseif($feed->media_type == "audio"): ?>
                    <audio style='width:100%' controls>
                        <source src="<?php echo e($feed->media); ?>" type="audio/<?php echo e($feed->media_ext); ?>">
                        Your browser does not support the video tag.
                    </audio>
                <?php else: ?>
                    <img width="100%" height="100%" src="<?php echo e($feed->user->profile->profile_image); ?>" alt="media">
                <?php endif; ?>
            </div>
            <div class="row interact px-4 mt-4">
                <i class="fas fa-headphones-alt"></i><span> 341</span>
                <i class="far fa-comments"></i> <span>43</span>
                <i class="far fa-thumbs-up"></i> <span>612</span>
            </div>
            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <div class="icon">
        <div class="row align-items-center">
            <div class="col">
                <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <div class="backgroundRound">
                    <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                </div>
            </div>
            <div class="col">
                <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('profile.show', Auth::user()->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
            </div>
        </div>
    </div>

    <div class="backgroundBar"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/feed/moment.blade.php ENDPATH**/ ?>