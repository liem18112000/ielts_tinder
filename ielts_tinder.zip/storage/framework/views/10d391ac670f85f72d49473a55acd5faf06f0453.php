<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesGetStarted.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <h1>Hello!</h1>
    <img src="<?php echo e(asset('image/logo.png')); ?>" alt="">
    <h2>IELTS TINDER</h2>
    <h6>GET CLOSER - GET HIGHER</h6>
    <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('signin-signup')); ?>" id="linkBtn"><button type="button" class="btn">GET STARTED</button></a>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('feeds.index')); ?>" id="linkBtn"><button type="button" class="btn"> HOME</button></a>
        <a class="btn" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views\index.blade.php ENDPATH**/ ?>