

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNewsfeed.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class='container' style='min-height:90vh'>
            <div class="chamthan_menu">
                <div class="menu">
                    <span><a href="<?php echo e(route('feeds.index')); ?>" class="linkNewsfeed navlink following">Following</a></span> |
                    <span><a href="<?php echo e(route('feeds.moment')); ?>" class="linkNewsfeed navlink moments">Hot</a></span>
                </div>

                <div class="chamthan">
                    <img class="chamthanicon" src="<?php echo e(asset('image/icon_chamthan.png')); ?>" alt=""></a>
                </div>
            </div>
            <div class= "boxcurved1">
                <div class="textcurved1">
                    <span><a href="<?php echo e(route('feeds.index')); ?>" >Speech</a></span>
                </div>
            </div>
            <div class= "boxcurved2">
                <div class="textcurved2">
                    <span><a href="<?php echo e(route('feeds.index')); ?>" >Sharings</a></span>
                </div>
            </div>

            <hr/>

            <div class="row">
                <div class="col-12" style='padding:0'>

                    <a class="btn btn-info btn-block"
                        style="background: linear-gradient(90deg,#9a75f0,#FFA4B6); font-weight:bold; color:white;"
                        href="<?php echo e(route('feeds.create')); ?>" role="button"> <i class="fa fa-plus" aria-hidden="true">
                            Post something now!</i></a>
                </div>
            </div>

            <hr/>

            <?php $__currentLoopData = $feeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($feed->status == 1): ?>
                <div class="row status-1">
                    <div class="col-2" style='padding:0; margin:0'>
                        <img style='border-radius: 50%' src="<?php echo e($feed->user->profile->profile_image); ?>" alt="avatar" class="avatar">
                    </div>
                    <div class="col-10">
                        <div class="row username">
                            <a href=""><?php echo e($feed->user->name); ?></a>
                        </div>
                        <b><h5><?php echo e($feed->decrypt($feed->title)); ?></h5></b>
                    </div>
                </div>

                <div class="row multimedia mt-4">
                    <?php if($feed->media_type == "video"): ?>
                        <video width="100%" height="100%" controls>
                            <source src="<?php echo e($feed->decrypt($feed->media)); ?>" type="video/<?php echo e($feed->media_ext); ?>">
                            Your browser does not support the video tag.
                        </video>
                    <?php elseif($feed->media_type == "audio"): ?>
                        <img style='object-fit:contain;' width="100%" height="80%" src="<?php echo e($feed->user->profile->profile_image); ?>" alt="media">
                        <audio style='width:100%' height="100%" controls>
                            <source src="<?php echo e($feed->decrypt($feed->media)); ?>" type="audio/<?php echo e($feed->media_ext); ?>">
                            Your browser does not support the video tag.
                        </audio>
                    <?php else: ?>
                        <img style='object-fit:contain' width="100%" height="100%" src="<?php echo e($feed->decrypt($feed->media)); ?>" alt="media">
                    <?php endif; ?>
                </div>

                <br/>

                <?php if(Auth::user()->id == $feed->user->id): ?>
                <div class='row' style='margin:0; padding:0'>

                    <div class='col-4' style='padding-left:0'>
                        <a class="btn btn-info btn-block" href="<?php echo e(route('feeds.edit-media', $feed->id)); ?>" role="button">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"> Media</i>
                        </a>
                    </div>

                    <div class='col-4' style='padding-left:0;padding-right:0'>
                        <a class="btn btn-warning btn-block" href="<?php echo e(route('feeds.edit-content', $feed->id)); ?>" role="button">
                            <i class="fa fa-pencil-square" aria-hidden="true"> Content</i>
                        </a>
                    </div>

                    <div class='col-4'  style='padding-right:0'>
                        <a class="btn btn-dark btn-block" href="<?php echo e(route('feeds.delete', $feed->id)); ?>" role="button">
                            <i class="fa fa-trash-o" aria-hidden="true"> Delete</i>
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <div class='row mt-2'>
                    <?php echo $feed->decrypt($feed->content); ?>

                </div>

                <div class="row interact px-4 mt-2">
                    <i class="fas fa-headphones-alt"><span> <?php echo e($feed->view_count); ?></span></i>
                </div>
                <hr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="icon">
        <div class="row align-items-center">
            <div class="col">
                <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <div class="backgroundRound">
                    <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                </div>
            </div>
            <div class="col">
                <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('profile.show', Auth::user()->profile->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
            </div>
        </div>
    </div>



    <div class="backgroundBar"></div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/feed/index.blade.php ENDPATH**/ ?>