

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/stylesNotifications.css')); ?>">
    <script src="https://kit.fontawesome.com/1918a957af.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class='content'>
    <div class="container">

        <br/><br/><br/>

        <video id="gum" playsinline autoplay muted ></video>
        <video id="recorded" playsinline loop width='100%'></video>

        <div class='row'>
            <button class='btn btn-primary btn-block' id="start">Start camera</button>
            <button class='btn btn-primary btn-block' id="record" disabled>Start Recording</button>
            <button class='btn btn-primary btn-block' id="play" disabled>Play</button>
            <button class='btn btn-primary btn-block' id="download" disabled>Download</button>
        </div>

        <div>
            <h4>Media Stream Constraints options</h4>
            <p>Echo cancellation: <input type="checkbox" id="echoCancellation"></p>
        </div>

        <div>
            <span id="errorMsg"></span>
        </div>

    </div>

    <div class="icon">
        <div class="row align-items-center">
            <div class="col">
                <a href="<?php echo e(route('feeds.index')); ?>"> <img class="iconNewsfeed" src="<?php echo e(asset('image/iconNewsfeed.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('search')); ?>"> <img class="iconSearch" src="<?php echo e(asset('image/icon_search.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <div class="backgroundRound">
                    <a href="<?php echo e(route('room.index')); ?>"> <img class="icon_Room" src="<?php echo e(asset('image/iconRoom.png')); ?>"></a>
                </div>
            </div>
            <div class="col">
                <a href="<?php echo e(route('notify.index')); ?>"> <img class="iconNoti" src="<?php echo e(asset('image/notification.png')); ?>" alt=""></a>
            </div>
            <div class="col">
                <a href="<?php echo e(route('profile.show', Auth::user()->profile->id)); ?>"> <img class="iconProfile" src="<?php echo e(asset('image/icon_profile.png')); ?>" alt=""></a>
            </div>
        </div>
    </div>

</div>

<div class="backgroundBar"></div>
</div>

<!-- include adapter for srcObject shim -->
<script src="https://webrtc.github.io/adapter/adapter-latest.js"></script>
<script src="<?php echo e(asset('js/record.js')); ?>" async></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appWithoutNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ielts_tinder\resources\views/record/index.blade.php ENDPATH**/ ?>