function SignInSignUp(){
    document.getElementById("linkBtn1").setAttribute("href","/html/signup-signin.html");
}
function SignUp(){
    document.getElementById("linkBtn2").setAttribute("href","/html/signup.html");
}
function SignIn(){
    document.getElementById("linkBtn3").setAttribute("href","/html/signin.html");
}
function AboutYourself(){
    document.getElementById("linkBtn4").setAttribute("href","/html/about-yourself.html");
}
function AboutPartner(){
    document.getElementById("linkBtn5").setAttribute("href","/html/AboutPartner.html");
}

function NewsfeedFollowing(){
    document.getElementById("linkBtn6").setAttribute("href","/html/newsfeed-following.html");
}
